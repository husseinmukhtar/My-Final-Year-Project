<?php
include("includes/db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $password = trim($_POST["password"]);
    $confirm_password = trim($_POST["confirm_password"]);
    $role = "user";

    if (empty($full_name) || empty($email) || empty($phone) || empty($password) || empty($confirm_password)) {
        $message = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $check_sql = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $message = "Email already exists.";
        } else {
            $sql = "INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $full_name, $email, $phone, $hashed_password, $role);

            if ($stmt->execute()) {
                $message = "Registration successful. You can now login.";
            } else {
                $message = "Something went wrong.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register - OMS</title>
  <!-- Font Awesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <!-- Background Decorators -->
  <div class="absolute top-[-20%] left-[-10%] w-96 h-96 bg-primary rounded-full mix-blend-screen filter blur-[128px] opacity-30 animate-pulse-slow"></div>
  <div class="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-secondary rounded-full mix-blend-screen filter blur-[128px] opacity-20"></div>

  <section class="form-section">
    <h2>Register</h2>
    <div class="form-container">
      <?php if ($message): ?>
        <p style="margin-bottom: 15px; color: #153677; font-weight: bold;"><?php echo $message; ?></p>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="full_name" placeholder="Enter your full name" />
        </div>

        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" placeholder="Enter your email" />
        </div>

        <div class="form-group">
          <label>Phone</label>
          <input type="text" name="phone" placeholder="Enter your phone number" />
        </div>

        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Enter your password" />
        </div>

        <div class="form-group">
          <label>Confirm Password</label>
          <input type="password" name="confirm_password" placeholder="Confirm your password" />
        </div>

        <button type="submit" class="submit-btn">Create Account</button>
      </form>
    </div>
  </section>
</body>
</html>