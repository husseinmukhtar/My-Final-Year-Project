<?php
include("includes/db.php");
$message_status = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donor_name = trim($_POST["donor_name"]);
    $donor_email = trim($_POST["donor_email"]);
    $donation_type = trim($_POST["donation_type"]);
    $currency = trim($_POST["currency"] ?? "USD");
    $amount = trim($_POST["amount"]);
    $item_description = trim($_POST["item_description"]);
    $donation_date = trim($_POST["donation_date"]);

    if (empty($donor_name) || empty($donor_email) || empty($donation_type) || empty($donation_date)) {
        $message_status = "Please fill in all required fields.";
    } else {
        $sql = "INSERT INTO donations (donor_name, donor_email, donation_type, currency, amount, item_description, donation_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssdss", $donor_name, $donor_email, $donation_type, $currency, $amount, $item_description, $donation_date);

        if ($stmt->execute()) {
            $message_status = "Donation submitted successfully.";
        } else {
            $message_status = "Failed to submit donation.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Donate - OMS</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header>
    <nav class="navbar">
      <h1 class="logo">OMS</h1>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="donate.php">Donate</a></li>
        <li><a href="login.php">Login</a></li>
      </ul>
    </nav>
  </header>

  <section class="form-section">
    <h2>Make a Donation</h2>
    <div class="form-container">
      <?php if ($message_status): ?>
        <p style="margin-bottom: 15px; color: #153677; font-weight: bold;"><?php echo $message_status; ?></p>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="donor_name" placeholder="Enter your name" />
        </div>

        <div class="form-group">
          <label>Email</label>
          <input type="email" name="donor_email" placeholder="Enter your email" />
        </div>

        <div class="form-group">
          <label>Donation Type</label>
          <select name="donation_type">
            <option value="">Select type</option>
            <option value="Cash">Cash</option>
            <option value="Items">Items</option>
          </select>
        </div>

        <div class="form-group" style="display: flex; gap: 10px;">
          <div style="flex: 1;">
            <label>Currency</label>
            <select name="currency">
              <option value="NGN">Naira (₦)</option>
              <option value="USD">Dollar ($)</option>
            </select>
          </div>
          <div style="flex: 2;">
            <label>Amount</label>
            <input type="number" step="0.01" name="amount" placeholder="Enter amount" />
          </div>
        </div>

        <div class="form-group">
          <label>Item Description</label>
          <textarea name="item_description" rows="4" placeholder="Describe the donated item"></textarea>
        </div>

        <div class="form-group">
          <label>Donation Date</label>
          <input type="date" name="donation_date" />
        </div>

        <button type="submit" class="submit-btn">Submit Donation</button>
      </form>
    </div>
  </section>
</body>
</html>