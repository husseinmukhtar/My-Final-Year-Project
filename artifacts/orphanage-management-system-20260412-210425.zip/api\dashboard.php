<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");

include_once '../includes/db.php';

// In a real app we'd verify a JWT token in the headers here. 
// For this prototype, we'll assume the mobile app requests are authenticated.

$stats = array();

// Total Children
$result = $conn->query("SELECT COUNT(*) as total FROM children");
$row = $result->fetch_assoc();
$stats['total_children'] = $row['total'];

// Total Staff
$result = $conn->query("SELECT COUNT(*) as total FROM users"); // Assuming users are staff
$row = $result->fetch_assoc();
$stats['total_staff'] = $row['total'];

// Static placeholders for donations & pending requests
$stats['total_donations'] = 200; 
$stats['pending_requests'] = 15;

echo json_encode(array(
    "status" => "success",
    "stats" => $stats
));
?>
