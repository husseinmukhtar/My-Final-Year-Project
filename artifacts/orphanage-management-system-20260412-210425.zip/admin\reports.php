<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$children_count = 0;
$staff_count = 0;
$donations_count = 0;
$adoption_count = 0;
$total_donation_amount = 0;

$children_result = $conn->query("SELECT COUNT(*) AS total FROM children");
if ($children_result) {
    $children_count = $children_result->fetch_assoc()['total'];
}

$staff_result = $conn->query("SELECT COUNT(*) AS total FROM staff");
if ($staff_result) {
    $staff_count = $staff_result->fetch_assoc()['total'];
}

$donations_result = $conn->query("SELECT COUNT(*) AS total FROM donations");
if ($donations_result) {
    $donations_count = $donations_result->fetch_assoc()['total'];
}

$adoption_result = $conn->query("SELECT COUNT(*) AS total FROM adoption_requests");
if ($adoption_result) {
    $adoption_count = $adoption_result->fetch_assoc()['total'];
}

$amount_result = $conn->query("SELECT SUM(amount) AS total_amount FROM donations");
if ($amount_result) {
    $row = $amount_result->fetch_assoc();
    $total_donation_amount = $row['total_amount'] ? $row['total_amount'] : 0;
}

$recent_requests = $conn->query("SELECT applicant_name, child_name, status, request_date FROM adoption_requests ORDER BY id DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Reports - OMS</title>
  <link rel="stylesheet" href="../css/style.css" />
  <style>
    .section-title {
      margin-top: 30px;
      margin-bottom: 15px;
      color: white;
    }

    .report-note {
      color: #aeb6d3;
      margin-top: 8px;
      margin-bottom: 10px;
    }

    .status-pill {
      display: inline-block;
      padding: 6px 12px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 600;
      background: rgba(255,255,255,0.08);
      color: white;
    }
  </style>
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <h2>OMS Admin</h2>
      <ul>
        <li>
          <a href="dashboard.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="children.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            <span>Children</span>
          </a>
        </li>
        <li>
          <a href="staff.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            <span>Staff</span>
          </a>
        </li>
        <li>
          <a href="donations.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Donations</span>
          </a>
        </li>
        <li>
          <a href="adoption.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Requests</span>
          </a>
        </li>
        <li>
          <a href="reports.php" class="active">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Reports</span>
          </a>
        </li>
        <li>
          <a href="../logout.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </aside>

    <main class="main-content">
      <h1>System Reports</h1>
      <p class="report-note">Overview of records and activities in the orphanage management system.</p>

      <div class="dashboard-cards">
        <div class="card">
          <h3><?php echo $children_count; ?></h3>
          <p>Total Children</p>
        </div>

        <div class="card">
          <h3><?php echo $staff_count; ?></h3>
          <p>Total Staff</p>
        </div>

        <div class="card">
          <h3><?php echo $donations_count; ?></h3>
          <p>Total Donations</p>
        </div>

        <div class="card">
          <h3><?php echo $adoption_count; ?></h3>
          <p>Total Adoption Requests</p>
        </div>

        <div class="card">
          <h3><?php echo number_format((float)$total_donation_amount, 2); ?></h3>
          <p>Total Donation Amount</p>
        </div>
      </div>

      <h2 class="section-title">Recent Adoption Requests</h2>

      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Applicant Name</th>
              <th>Child Name</th>
              <th>Status</th>
              <th>Request Date</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($recent_requests && $recent_requests->num_rows > 0): ?>
              <?php while ($row = $recent_requests->fetch_assoc()): ?>
                <tr>
                  <td><?php echo htmlspecialchars($row['applicant_name']); ?></td>
                  <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                  <td><span class="status-pill"><?php echo htmlspecialchars($row['status']); ?></span></td>
                  <td><?php echo htmlspecialchars($row['request_date']); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="4">No adoption requests found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
  <script src="../js/script.js"></script>
</body>
</html>