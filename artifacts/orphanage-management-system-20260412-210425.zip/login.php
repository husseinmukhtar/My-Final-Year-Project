<?php
session_start();
include("includes/db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (empty($email) || empty($password)) {
        $message = "Please fill in all fields.";
    } else {
        $sql = "SELECT id, full_name, email, password, role FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user["password"])) {
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["full_name"] = $user["full_name"];
                $_SESSION["role"] = $user["role"];

                header("Location: admin/dashboard.php");
                exit();
            } else {
                $message = "Invalid password.";
            }
        } else {
            $message = "User not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - OMS</title>
  <!-- Font Awesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <!-- Background Decorators -->
  <div class="absolute top-[-20%] left-[-10%] w-96 h-96 bg-primary rounded-full mix-blend-screen filter blur-[128px] opacity-30 animate-pulse-slow"></div>
  <div class="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-secondary rounded-full mix-blend-screen filter blur-[128px] opacity-20"></div>

  <section class="form-section">
    <h2>Login</h2>
    <div class="form-container">
      <?php if ($message): ?>
        <p style="margin-bottom: 15px; color: red; font-weight: bold;"><?php echo $message; ?></p>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" placeholder="Enter your email" />
        </div>

        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Enter your password" />
        </div>

        <button type="submit" class="submit-btn">Login</button>
      </form>
    </div>
  </section>
</body>
</html>