<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$message = "";
$edit_mode = false;
$edit_request = null;

/* Delete record */
if (isset($_GET["delete"])) {
    $delete_id = intval($_GET["delete"]);
    $stmt = $conn->prepare("DELETE FROM adoption_requests WHERE id = ?");

    if (!$stmt) {
        die("SQL Prepare Error: " . $conn->error);
    }

    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Adoption request deleted successfully.";
    } else {
        $message = "Failed to delete adoption request.";
    }
}

/* Edit record */
if (isset($_GET["edit"])) {
    $edit_id = intval($_GET["edit"]);
    $stmt = $conn->prepare("SELECT * FROM adoption_requests WHERE id = ?");

    if (!$stmt) {
        die("SQL Prepare Error: " . $conn->error);
    }

    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result_edit = $stmt->get_result();

    if ($result_edit->num_rows === 1) {
        $edit_request = $result_edit->fetch_assoc();
        $edit_mode = true;
    }
}

/* Add or Update record */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $applicant_name = trim($_POST["applicant_name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $address = trim($_POST["address"]);
    $child_name = trim($_POST["child_name"]);
    $status = trim($_POST["status"]);
    $request_date = trim($_POST["request_date"]);

    if (
        empty($applicant_name) || empty($email) || empty($phone) ||
        empty($address) || empty($child_name) || empty($status) || empty($request_date)
    ) {
        $message = "Please fill in all required fields.";
    } else {
        if (isset($_POST["request_id"]) && !empty($_POST["request_id"])) {
            $request_id = intval($_POST["request_id"]);

            $sql = "UPDATE adoption_requests
                    SET applicant_name = ?, email = ?, phone = ?, address = ?, child_name = ?, status = ?, request_date = ?
                    WHERE id = ?";

            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                die("SQL Prepare Error: " . $conn->error);
            }

            $stmt->bind_param(
                "sssssssi",
                $applicant_name,
                $email,
                $phone,
                $address,
                $child_name,
                $status,
                $request_date,
                $request_id
            );

            if ($stmt->execute()) {
                $message = "Adoption request updated successfully.";
                $edit_mode = false;
                $edit_request = null;
            } else {
                $message = "Failed to update adoption request.";
            }
        } else {
            $sql = "INSERT INTO adoption_requests (applicant_name, email, phone, address, child_name, status, request_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                die("SQL Prepare Error: " . $conn->error);
            }

            $stmt->bind_param(
                "sssssss",
                $applicant_name,
                $email,
                $phone,
                $address,
                $child_name,
                $status,
                $request_date
            );

            if ($stmt->execute()) {
                $message = "Adoption request added successfully.";
            } else {
                $message = "Failed to add adoption request.";
            }
        }
    }
}

$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}

if ($search != "") {
    $sql = "SELECT * FROM adoption_requests WHERE applicant_name LIKE ? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $search_value = "%" . $search . "%";
    $stmt->bind_param("s", $search_value);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM adoption_requests ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Adoption Requests - OMS</title>
  <link rel="stylesheet" href="../css/style.css" />
  <style>
    .status-pill {
      display: inline-block;
      padding: 6px 12px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 600;
      background: rgba(21, 54, 119, 0.10);
      color: #153677;
      border: 1px solid rgba(21, 54, 119, 0.18);
    }
  </style>
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <h2>OMS Admin</h2>
      <ul>
        <li>
          <a href="dashboard.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="children.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            <span>Children</span>
          </a>
        </li>
        <li>
          <a href="staff.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            <span>Staff</span>
          </a>
        </li>
        <li>
          <a href="donations.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Donations</span>
          </a>
        </li>
        <li>
          <a href="adoption.php" class="active">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Requests</span>
          </a>
        </li>
        <li>
          <a href="reports.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Reports</span>
          </a>
        </li>
        <li>
          <a href="../logout.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="page-wrap">
        <h1>Adoption Requests Management</h1>
        <p>Add, update, view, and delete adoption requests.</p>

        <?php if ($message): ?>
          <div class="message-box"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="form-container" style="max-width: 700px; margin: 20px 0;">
          <h2 class="form-title"><?php echo $edit_mode ? "Edit Adoption Request" : "Add New Adoption Request"; ?></h2>

          <form method="POST" action="">
            <input type="hidden" name="request_id" value="<?php echo $edit_mode ? $edit_request['id'] : ''; ?>">

            <div class="form-group">
              <label>Applicant Name</label>
              <input type="text" name="applicant_name" value="<?php echo $edit_mode ? htmlspecialchars($edit_request['applicant_name']) : ''; ?>">
            </div>

            <div class="form-group">
              <label>Email</label>
              <input type="email" name="email" value="<?php echo $edit_mode ? htmlspecialchars($edit_request['email']) : ''; ?>">
            </div>

            <div class="form-group">
              <label>Phone</label>
              <input type="text" name="phone" value="<?php echo $edit_mode ? htmlspecialchars($edit_request['phone']) : ''; ?>">
            </div>

            <div class="form-group">
              <label>Address</label>
              <textarea name="address" rows="4"><?php echo $edit_mode ? htmlspecialchars($edit_request['address']) : ''; ?></textarea>
            </div>

            <div class="form-group">
              <label>Child Name</label>
              <input type="text" name="child_name" value="<?php echo $edit_mode ? htmlspecialchars($edit_request['child_name']) : ''; ?>">
            </div>

            <div class="form-group">
              <label>Status</label>
              <select name="status">
                <option value="">Select status</option>
                <option value="Pending" <?php echo ($edit_mode && $edit_request['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                <option value="Approved" <?php echo ($edit_mode && $edit_request['status'] == 'Approved') ? 'selected' : ''; ?>>Approved</option>
                <option value="Rejected" <?php echo ($edit_mode && $edit_request['status'] == 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
              </select>
            </div>

            <div class="form-group">
              <label>Request Date</label>
              <input type="date" name="request_date" value="<?php echo $edit_mode ? htmlspecialchars($edit_request['request_date']) : ''; ?>">
            </div>

            <button type="submit" class="submit-btn">
              <?php echo $edit_mode ? "Update Request" : "Add Request"; ?>
            </button>
          </form>
        </div>
        <div class="form-container" style="max-width: 100%; margin: 20px 0; padding: 20px;">
          <form method="GET" action="" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; flex: 1; max-width: 300px;">
              <input type="text" name="search" placeholder="Adoption Request Name" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <button type="submit" class="btn btn-primary" style="padding: 12px 24px; border-radius: 12px;">Search</button>
            <a href="adoption.php" class="btn btn-outline" style="padding: 12px 24px; border-radius: 12px;">Reset</a>
          </form>
        </div>
        <div class="table-container">
          <h2>Adoption Request Records</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Applicant Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Child Name</th>
                <th>Status</th>
                <th>Request Date</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo htmlspecialchars($row["applicant_name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["email"]); ?></td>
                    <td><?php echo htmlspecialchars($row["phone"]); ?></td>
                    <td><?php echo htmlspecialchars($row["address"]); ?></td>
                    <td><?php echo htmlspecialchars($row["child_name"]); ?></td>
                    <td><span class="status-pill"><?php echo htmlspecialchars($row["status"]); ?></span></td>
                    <td><?php echo htmlspecialchars($row["request_date"]); ?></td>
                    <td><?php echo htmlspecialchars($row["created_at"]); ?></td>
                    <td>
                      <div class="actions">
                        <a class="action-btn edit-btn" href="adoption.php?edit=<?php echo $row['id']; ?>">Edit</a>
                        <a class="action-btn delete-btn" href="adoption.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this request?');">Delete</a>
                      </div>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="10">No adoption requests found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
  <script src="../js/script.js"></script>
</body>
</html>