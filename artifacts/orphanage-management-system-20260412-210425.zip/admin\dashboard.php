<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$children_count = 0;
$staff_count = 0;
$donations_count = 0;
$pending_requests = 0;

$children_result = $conn->query("SELECT COUNT(*) AS total FROM children");
if ($children_result) {
    $children_count = $children_result->fetch_assoc()['total'];
}

$staff_result = $conn->query("SELECT COUNT(*) AS total FROM staff");
if ($staff_result) {
    $staff_count = $staff_result->fetch_assoc()['total'];
}

$donations_result = $conn->query("SELECT COUNT(*) AS total FROM donations");
if ($donations_result) {
    $donations_count = $donations_result->fetch_assoc()['total'];
}

$pending_result = $conn->query("SELECT COUNT(*) AS total FROM adoption_requests WHERE status = 'Pending'");
if ($pending_result) {
    $pending_requests = $pending_result->fetch_assoc()['total'];
}

$recent_children = $conn->query("SELECT id, full_name, gender, admission_date, health_status FROM children ORDER BY id DESC LIMIT 5");
$recent_donations = $conn->query("SELECT id, donor_name, donation_type, amount, donation_date FROM donations ORDER BY id DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard - OMS</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <h2>OMS Admin</h2>
      <ul>
        <li>
          <a href="dashboard.php" class="active">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="children.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            <span>Children</span>
          </a>
        </li>
        <li>
          <a href="staff.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            <span>Staff</span>
          </a>
        </li>
        <li>
          <a href="donations.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Donations</span>
          </a>
        </li>
        <li>
          <a href="adoption.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Requests</span>
          </a>
        </li>
        <li>
          <a href="reports.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Reports</span>
          </a>
        </li>
        <li>
          <a href="../logout.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="page-wrap">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION["full_name"]); ?></h1>
        <p>You have successfully logged in.</p>

        <div class="dashboard-cards">
          <div class="card">
            <h3><?php echo $children_count; ?></h3>
            <p>Total Children</p>
          </div>

          <div class="card">
            <h3><?php echo $staff_count; ?></h3>
            <p>Total Staff</p>
          </div>

          <div class="card">
            <h3><?php echo $donations_count; ?></h3>
            <p>Total Donations</p>
          </div>

          <div class="card">
            <h3><?php echo $pending_requests; ?></h3>
            <p>Pending Requests</p>
          </div>
        </div>

        <div class="table-container" style="margin-bottom: 40px;">
          <h2>Recent Children</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Gender</th>
                <th>Admission Date</th>
                <th>Health Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($recent_children && $recent_children->num_rows > 0): ?>
                <?php while ($row = $recent_children->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo htmlspecialchars($row["full_name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["gender"]); ?></td>
                    <td><?php echo htmlspecialchars($row["admission_date"]); ?></td>
                    <td><?php echo htmlspecialchars($row["health_status"]); ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5">No recent children found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <div class="table-container" style="margin-bottom: 40px;">
          <h2>Recent Donations</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Donor Name</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($recent_donations && $recent_donations->num_rows > 0): ?>
                <?php while ($row = $recent_donations->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo htmlspecialchars($row["donor_name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["donation_type"]); ?></td>
                    <td><?php echo htmlspecialchars($row["amount"]); ?></td>
                    <td><?php echo htmlspecialchars($row["donation_date"]); ?></td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5">No recent donations found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div>
    </main>
  </div>
  <script src="../js/script.js"></script>
</body>
</html>