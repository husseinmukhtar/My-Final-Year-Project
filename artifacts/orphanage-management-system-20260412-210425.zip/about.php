<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About - OMS</title>
  <!-- Font Awesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <!-- Background Decorators -->
  <div class="absolute top-[-20%] left-[-10%] w-96 h-96 bg-primary rounded-full mix-blend-screen filter blur-[128px] opacity-30 animate-pulse-slow"></div>
  <div class="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-secondary rounded-full mix-blend-screen filter blur-[128px] opacity-20"></div>

  <header>
    <nav class="navbar">
      <h1 class="logo"><i class="fa-solid fa-hands-holding-child text-primary mr-2"></i> OMS<span class="text-primary text-xs ml-1 font-mono">SYSTEM</span></h1>
      <ul class="nav-links">
        <li class="desktop-only"><a href="index.php">Home</a></li>
        <li class="desktop-only"><a href="about.php">About</a></li>
        <li class="desktop-only"><a href="contact.php">Contact</a></li>
        <li><a href="donate.php" class="btn btn-donate shimmer-btn">Donate <i class="fa-solid fa-heart ml-1"></i></a></li>
        <li><a href="login.php" class="btn btn-outline btn-small">Login</a></li>
      </ul>
    </nav>
  </header>

  <section class="page-section">
    <h2>About the System</h2>
    <p>
      The Orphanage Management System is designed to help orphanages manage
      children records, staff information, donations, and adoption requests
      in a safe and organized way.
    </p>
  </section>

  <section class="features">
    <div class="feature-box">
      <div class="card">
        <h3>Mission</h3>
        <p>To improve the care and management of children through technology.</p>
      </div>
      <div class="card">
        <h3>Vision</h3>
        <p>To provide a reliable digital system for efficient orphanage operations.</p>
      </div>
      <div class="card">
        <h3>Goal</h3>
        <p>To support better record keeping and faster decision-making.</p>
      </div>
    </div>
  </section>

  <footer>
    <p>&copy; 2026 Orphanage Management System. All rights reserved.</p>
  </footer>
</body>
</html>