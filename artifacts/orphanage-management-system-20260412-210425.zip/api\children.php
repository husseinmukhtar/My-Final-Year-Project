<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../includes/db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM children ORDER BY id DESC";
        $result = $conn->query($sql);

        $children = array();
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $children[] = $row;
            }
        }
        echo json_encode(array("status" => "success", "data" => $children));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->full_name) && !empty($data->gender) && !empty($data->date_of_birth) && 
            !empty($data->health_status) && !empty($data->education_level) && !empty($data->admission_date)) {
            
            $sql = "INSERT INTO children (full_name, gender, date_of_birth, health_status, education_level, admission_date, guardian_note) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            $guardian_note = isset($data->guardian_note) ? $data->guardian_note : "";
            
            $stmt->bind_param("sssssss", $data->full_name, $data->gender, $data->date_of_birth, $data->health_status, $data->education_level, $data->admission_date, $guardian_note);
            
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("status" => "success", "message" => "Child record created."));
            } else {
                http_response_code(503);
                echo json_encode(array("status" => "error", "message" => "Unable to create child record."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("status" => "error", "message" => "Incomplete data. Please provide all required fields."));
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->id)) {
            $sql = "UPDATE children SET full_name = ?, gender = ?, date_of_birth = ?, health_status = ?, education_level = ?, admission_date = ?, guardian_note = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            
            $stmt->bind_param("sssssssi", $data->full_name, $data->gender, $data->date_of_birth, $data->health_status, $data->education_level, $data->admission_date, $data->guardian_note, $data->id);
            
            if ($stmt->execute()) {
                echo json_encode(array("status" => "success", "message" => "Child record updated."));
            } else {
                http_response_code(503);
                echo json_encode(array("status" => "error", "message" => "Unable to update child record."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("status" => "error", "message" => "Missing child ID for update."));
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->id)) {
            $sql = "DELETE FROM children WHERE id = ?";
            $stmt = $conn->prepare($sql);
            
            $stmt->bind_param("i", $data->id);
            
            if ($stmt->execute()) {
                echo json_encode(array("status" => "success", "message" => "Child record deleted."));
            } else {
                http_response_code(503);
                echo json_encode(array("status" => "error", "message" => "Unable to delete child record."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("status" => "error", "message" => "Missing child ID for deletion."));
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(array("status" => "error", "message" => "Method not allowed."));
        break;
}
?>
