<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$message = "";
$edit_mode = false;
$edit_staff = null;

/* Delete record */
if (isset($_GET["delete"])) {
    $delete_id = intval($_GET["delete"]);

    $stmt = $conn->prepare("DELETE FROM staff WHERE id = ?");
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Staff record deleted successfully.";
    } else {
        $message = "Failed to delete staff record.";
    }
}

/* Edit record */
if (isset($_GET["edit"])) {
    $edit_id = intval($_GET["edit"]);
    $stmt = $conn->prepare("SELECT * FROM staff WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result_edit = $stmt->get_result();

    if ($result_edit->num_rows === 1) {
        $edit_staff = $result_edit->fetch_assoc();
        $edit_mode = true;
    }
}

/* Add or Update record */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $role = trim($_POST["role"]);
    $address = trim($_POST["address"]);
    $date_joined = trim($_POST["date_joined"]);

    if (
        empty($full_name) || empty($email) || empty($phone) ||
        empty($role) || empty($date_joined)
    ) {
        $message = "Please fill in all required fields.";
    } else {
        if (isset($_POST["staff_id"]) && !empty($_POST["staff_id"])) {
            $staff_id = intval($_POST["staff_id"]);

            $sql = "UPDATE staff 
                    SET full_name = ?, email = ?, phone = ?, role = ?, address = ?, date_joined = ?
                    WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssi",
                $full_name,
                $email,
                $phone,
                $role,
                $address,
                $date_joined,
                $staff_id
            );

            if ($stmt->execute()) {
                $message = "Staff record updated successfully.";
                $edit_mode = false;
                $edit_staff = null;
            } else {
                $message = "Failed to update staff record.";
            }
        } else {
            $check_sql = "SELECT id FROM staff WHERE email = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $email);
            $check_stmt->execute();
            $check_stmt->store_result();

            if ($check_stmt->num_rows > 0) {
                $message = "Staff email already exists.";
            } else {
                $sql = "INSERT INTO staff (full_name, email, phone, role, address, date_joined)
                        VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param(
                    "ssssss",
                    $full_name,
                    $email,
                    $phone,
                    $role,
                    $address,
                    $date_joined
                );

                if ($stmt->execute()) {
                    $message = "Staff record added successfully.";
                } else {
                    $message = "Failed to add staff record.";
                }
            }
        }
    }
}

$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}

if ($search != "") {
    $sql = "SELECT * FROM staff WHERE full_name LIKE ? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $search_value = "%" . $search . "%";
    $stmt->bind_param("s", $search_value);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM staff ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Staff Management - OMS</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <h2>OMS Admin</h2>
      <ul>
        <li>
          <a href="dashboard.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="children.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            <span>Children</span>
          </a>
        </li>
        <li>
          <a href="staff.php" class="active">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            <span>Staff</span>
          </a>
        </li>
        <li>
          <a href="donations.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Donations</span>
          </a>
        </li>
        <li>
          <a href="adoption.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Requests</span>
          </a>
        </li>
        <li>
          <a href="../logout.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="page-wrap">
        <h1>Staff Management</h1>
        <p>Add, update, view, and delete staff records.</p>

        <?php if ($message): ?>
          <div class="message-box"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="form-container" style="max-width: 700px; margin: 20px 0;">
          <h2 class="form-title"><?php echo $edit_mode ? "Edit Staff" : "Add New Staff"; ?></h2>

          <form method="POST" action="">
            <input type="hidden" name="staff_id" value="<?php echo $edit_mode ? $edit_staff['id'] : ''; ?>">

            <div class="form-group">
              <label>Full Name</label>
              <input type="text" name="full_name" placeholder="Enter full name"
                value="<?php echo $edit_mode ? htmlspecialchars($edit_staff['full_name']) : ''; ?>" />
            </div>

            <div class="form-group">
              <label>Email</label>
              <input type="email" name="email" placeholder="Enter email"
                value="<?php echo $edit_mode ? htmlspecialchars($edit_staff['email']) : ''; ?>" />
            </div>

            <div class="form-group">
              <label>Phone</label>
              <input type="text" name="phone" placeholder="Enter phone number"
                value="<?php echo $edit_mode ? htmlspecialchars($edit_staff['phone']) : ''; ?>" />
            </div>

            <div class="form-group">
              <label>Role</label>
              <input type="text" name="role" placeholder="Enter role"
                value="<?php echo $edit_mode ? htmlspecialchars($edit_staff['role']) : ''; ?>" />
            </div>

            <div class="form-group">
              <label>Address</label>
              <textarea name="address" rows="4" placeholder="Enter address"><?php echo $edit_mode ? htmlspecialchars($edit_staff['address']) : ''; ?></textarea>
            </div>

            <div class="form-group">
              <label>Date Joined</label>
              <input type="date" name="date_joined"
                value="<?php echo $edit_mode ? htmlspecialchars($edit_staff['date_joined']) : ''; ?>" />
            </div>

            <button type="submit" class="submit-btn">
              <?php echo $edit_mode ? "Update Staff" : "Add Staff"; ?>
            </button>
          </form>
        </div>
        <div class="form-container" style="max-width: 100%; margin: 20px 0; padding: 20px;">
          <form method="GET" action="" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; flex: 1; max-width: 300px;">
              <input type="text" name="search" placeholder="Search by staff name" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <button type="submit" class="btn btn-primary" style="padding: 12px 24px; border-radius: 12px;">Search</button>
            <a href="staff.php" class="btn btn-outline" style="padding: 12px 24px; border-radius: 12px;">Reset</a>
          </form>
        </div>
        <div class="table-container">
          <h2>Staff Records</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Address</th>
                <th>Date Joined</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo htmlspecialchars($row["full_name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["email"]); ?></td>
                    <td><?php echo htmlspecialchars($row["phone"]); ?></td>
                    <td><?php echo htmlspecialchars($row["role"]); ?></td>
                    <td><?php echo htmlspecialchars($row["address"]); ?></td>
                    <td><?php echo htmlspecialchars($row["date_joined"]); ?></td>
                    <td><?php echo htmlspecialchars($row["created_at"]); ?></td>
                    <td>
                      <div class="actions">
                        <a class="action-btn edit-btn" href="staff.php?edit=<?php echo $row['id']; ?>">Edit</a>
                        <a class="action-btn delete-btn" href="staff.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                      </div>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="9">No staff records found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
  <script src="../js/script.js"></script>
</body>
</html>