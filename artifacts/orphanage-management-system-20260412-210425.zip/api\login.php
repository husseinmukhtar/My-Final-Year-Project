<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include_once '../includes/db.php';

$data = json_decode(file_get_contents("php://input"));

if (isset($data->email) && isset($data->password)) {
    $email = trim($data->email);
    $password = trim($data->password);

    $sql = "SELECT id, full_name, email, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // For security, usually you would use password_verify. 
        // Based on the login.php logic it was using password_verify.
        if (password_verify($password, $user["password"])) {
            http_response_code(200);
            echo json_encode(array(
                "status" => "success",
                "message" => "Login successful",
                "user" => array(
                    "id" => $user["id"],
                    "full_name" => $user["full_name"],
                    "email" => $user["email"],
                    "role" => $user["role"]
                )
            ));
        } else {
            http_response_code(401);
            echo json_encode(array("status" => "error", "message" => "Invalid password."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("status" => "error", "message" => "User not found."));
    }
} else {
    http_response_code(400);
    echo json_encode(array("status" => "error", "message" => "Incomplete data. Please provide email and password."));
}
?>
