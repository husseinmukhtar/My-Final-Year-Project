<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$message = "";
$edit_mode = false;
$edit_donation = null;

if (isset($_GET["delete"])) {
    $delete_id = intval($_GET["delete"]);
    $stmt = $conn->prepare("DELETE FROM donations WHERE id = ?");
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Donation record deleted successfully.";
    } else {
        $message = "Failed to delete donation record.";
    }
}

if (isset($_GET["edit"])) {
    $edit_id = intval($_GET["edit"]);
    $stmt = $conn->prepare("SELECT * FROM donations WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result_edit = $stmt->get_result();

    if ($result_edit->num_rows === 1) {
        $edit_donation = $result_edit->fetch_assoc();
        $edit_mode = true;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donor_name = trim($_POST["donor_name"]);
    $donor_email = trim($_POST["donor_email"]);
    $donation_type = trim($_POST["donation_type"]);
    $currency = trim($_POST["currency"] ?? "USD");
    $amount = trim($_POST["amount"]);
    $item_description = trim($_POST["item_description"]);
    $donation_date = trim($_POST["donation_date"]);

    if (empty($donor_name) || empty($donor_email) || empty($donation_type) || empty($donation_date)) {
        $message = "Please fill in all required fields.";
    } else {
        if (isset($_POST["donation_id"]) && !empty($_POST["donation_id"])) {
            $donation_id = intval($_POST["donation_id"]);

            $sql = "UPDATE donations 
                    SET donor_name = ?, donor_email = ?, donation_type = ?, currency = ?, amount = ?, item_description = ?, donation_date = ?
                    WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssdssi", $donor_name, $donor_email, $donation_type, $currency, $amount, $item_description, $donation_date, $donation_id);

            if ($stmt->execute()) {
                $message = "Donation record updated successfully.";
                $edit_mode = false;
                $edit_donation = null;
            } else {
                $message = "Failed to update donation record.";
            }
        } else {
            $sql = "INSERT INTO donations (donor_name, donor_email, donation_type, currency, amount, item_description, donation_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssdss", $donor_name, $donor_email, $donation_type, $currency, $amount, $item_description, $donation_date);

            if ($stmt->execute()) {
                $message = "Donation record added successfully.";
            } else {
                $message = "Failed to add donation record.";
            }
        }
    }
}

$search = "";

if (isset($_GET["search"])) {
    $search = trim($_GET["search"]);
}

if ($search != "") {
    $sql = "SELECT * FROM donations WHERE donor_name LIKE ? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $search_value = "%" . $search . "%";
    $stmt->bind_param("s", $search_value);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM donations ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Donations Management - OMS</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <h2>OMS Admin</h2>
      <ul>
        <li>
          <a href="dashboard.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="children.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            <span>Children</span>
          </a>
        </li>
        <li>
          <a href="staff.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            <span>Staff</span>
          </a>
        </li>
        <li>
          <a href="donations.php" class="active">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Donations</span>
          </a>
        </li>
        <li>
          <a href="adoption.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            <span>Requests</span>
          </a>
        </li>
        <li>
          <a href="../logout.php">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </aside>

    <main class="main-content">
      <div class="page-wrap">
        <h1>Donations Management</h1>
        <p>Add, update, view, and delete donation records.</p>

        <?php if ($message): ?>
          <div class="message-box"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="form-container" style="max-width: 700px; margin: 20px 0;">
          <h2 class="form-title"><?php echo $edit_mode ? "Edit Donation" : "Add New Donation"; ?></h2>

          <form method="POST" action="">
            <input type="hidden" name="donation_id" value="<?php echo $edit_mode ? $edit_donation['id'] : ''; ?>">

            <div class="form-group">
              <label>Donor Name</label>
              <input type="text" name="donor_name" value="<?php echo $edit_mode ? htmlspecialchars($edit_donation['donor_name']) : ''; ?>">
            </div>

            <div class="form-group">
              <label>Donor Email</label>
              <input type="email" name="donor_email" value="<?php echo $edit_mode ? htmlspecialchars($edit_donation['donor_email']) : ''; ?>">
            </div>

            <div class="form-group">
              <label>Donation Type</label>
              <select name="donation_type">
                <option value="">Select type</option>
                <option value="Cash" <?php echo ($edit_mode && $edit_donation['donation_type'] == 'Cash') ? 'selected' : ''; ?>>Cash</option>
                <option value="Items" <?php echo ($edit_mode && $edit_donation['donation_type'] == 'Items') ? 'selected' : ''; ?>>Items</option>
              </select>
            </div>

            <div class="form-group" style="display: flex; gap: 10px;">
              <div style="flex: 1;">
                <label>Currency</label>
                <select name="currency">
                  <option value="NGN" <?php echo ($edit_mode && isset($edit_donation['currency']) && $edit_donation['currency'] == 'NGN') ? 'selected' : ''; ?>>Naira (₦)</option>
                  <option value="USD" <?php echo (!$edit_mode || (isset($edit_donation['currency']) && $edit_donation['currency'] == 'USD')) ? 'selected' : ''; ?>>Dollar ($)</option>
                </select>
              </div>
              <div style="flex: 2;">
                <label>Amount</label>
                <input type="number" step="0.01" name="amount" value="<?php echo $edit_mode ? htmlspecialchars($edit_donation['amount']) : ''; ?>">
              </div>
            </div>

            <div class="form-group">
              <label>Item Description</label>
              <textarea name="item_description" rows="4"><?php echo $edit_mode ? htmlspecialchars($edit_donation['item_description']) : ''; ?></textarea>
            </div>

            <div class="form-group">
              <label>Donation Date</label>
              <input type="date" name="donation_date" value="<?php echo $edit_mode ? htmlspecialchars($edit_donation['donation_date']) : ''; ?>">
            </div>

            <button type="submit" class="submit-btn">
              <?php echo $edit_mode ? "Update Donation" : "Add Donation"; ?>
            </button>
          </form>
        </div>
        <div class="form-container" style="max-width: 100%; margin: 20px 0; padding: 20px;">
          <form method="GET" action="" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; flex: 1; max-width: 300px;">
              <input type="text" name="search" placeholder="Search by donor name" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <button type="submit" class="btn btn-primary" style="padding: 12px 24px; border-radius: 12px;">Search</button>
            <a href="donations.php" class="btn btn-outline" style="padding: 12px 24px; border-radius: 12px;">Reset</a>
          </form>
        </div>
        <div class="table-container">
          <h2>Donation Records</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Donor Name</th>
                <th>Donor Email</th>
                <th>Type</th>
                <th>Currency</th>
                <th>Amount</th>
                <th>Item Description</th>
                <th>Donation Date</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo htmlspecialchars($row["donor_name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["donor_email"]); ?></td>
                    <td><?php echo htmlspecialchars($row["donation_type"]); ?></td>
                    <td><?php echo htmlspecialchars($row["currency"] ?? "USD"); ?></td>
                    <td><?php echo htmlspecialchars($row["amount"]); ?></td>
                    <td><?php echo htmlspecialchars($row["item_description"]); ?></td>
                    <td><?php echo htmlspecialchars($row["donation_date"]); ?></td>
                    <td><?php echo htmlspecialchars($row["created_at"]); ?></td>
                    <td>
                      <div class="actions">
                        <a class="action-btn edit-btn" href="donations.php?edit=<?php echo $row['id']; ?>">Edit</a>
                        <a class="action-btn delete-btn" href="donations.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                      </div>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="9">No donation records found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
  <script src="../js/script.js"></script>
</body>
</html>