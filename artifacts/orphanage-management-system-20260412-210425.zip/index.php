<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Orphanage Management System</title>
  <!-- Font Awesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>

  <!-- Background Decorators -->
  <div class="absolute top-[-20%] left-[-10%] w-96 h-96 bg-primary rounded-full mix-blend-screen filter blur-[128px] opacity-30 animate-pulse-slow"></div>
  <div class="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-secondary rounded-full mix-blend-screen filter blur-[128px] opacity-20"></div>

  <header>
    <nav class="navbar">
      <h1 class="logo"><i class="fa-solid fa-hands-holding-child text-primary mr-2"></i> OMS<span class="text-primary text-xs ml-1 font-mono">SYSTEM</span></h1>
      <ul class="nav-links">
        <li class="desktop-only"><a href="index.php">Home</a></li>
        <li class="desktop-only"><a href="about.php">About</a></li>
        <li class="desktop-only"><a href="contact.php">Contact</a></li>
        <li><a href="donate.php" class="btn btn-donate shimmer-btn">Donate <i class="fa-solid fa-heart ml-1"></i></a></li>
        <li><a href="login.php" class="btn btn-outline btn-small">Login</a></li>
      </ul>
    </nav>
  </header>

  <main class="flex-grow flex flex-col items-center justify-center relative z-10">
    <section class="hero exciting-hero">
      <div class="hero-content">
        <div class="hero-left text-center">
          <p class="hero-tag">Care • Support • Hope</p>
        <h2>Building a Better Future for Every Child</h2>
        <p class="hero-desc">
          A smart orphanage management system for managing children records,
          staff, donations, and adoption requests in one secure place.
        </p>

        <div class="hero-buttons">
          <a href="login.php" class="btn btn-primary shimmer-btn">Login / Dashboard</a>
          <a href="donate.php" class="btn btn-donate shimmer-btn">Donate Now <i class="fa-solid fa-heart ml-1"></i></a>
        </div>

        <div class="quick-stats">
          <div class="mini-stat">
            <h3>120+</h3>
            <p>Children</p>
          </div>
          <div class="mini-stat">
            <h3>35+</h3>
            <p>Staff</p>
          </div>
          <div class="mini-stat">
            <h3>200+</h3>
            <p>Donors</p>
          </div>
        </div>
      </div>

      <div class="hero-right">
        <div class="hero-card floating-card">
          <h3>Why This System Matters</h3>
          <p>It helps orphanages keep accurate records, respond faster, and serve children better.</p>
          <ul>
            <li>Manage child records</li>
            <li>Track donations</li>
            <li>Monitor staff</li>
            <li>Handle adoption requests</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section class="welcome-section">
    <div class="welcome-text">
      <h2>Welcome to OMS</h2>
      <p>
        The Orphanage Management System is designed to improve the way orphanages
        organize daily activities and store important information. It reduces paperwork,
        improves efficiency, and supports better care for children.
      </p>
    </div>
  </section>

  <section class="features">
    <h2>Core Features</h2>
    <div class="feature-box">
      <div class="card">
        <div class="icon"><i class="fa-solid fa-child"></i></div>
        <h3>Child Records</h3>
        <p>Store health, education, and personal details safely and clearly.</p>
      </div>
      <div class="card hover-card icon-card">
        <div class="icon"><i class="fa-solid fa-chalkboard-user"></i></div>
        <h3>Staff Management</h3>
        <p>Manage staff profiles, roles, and responsibilities with ease.</p>
      </div>
      <div class="card hover-card icon-card">
        <div class="icon"><i class="fa-solid fa-hand-holding-heart"></i></div>
        <h3>Donations</h3>
        <p>Track cash and item donations from donors in an organized way.</p>
      </div>
      <div class="card hover-card icon-card">
        <div class="icon"><i class="fa-solid fa-file-signature"></i></div>
        <h3>Adoption Requests</h3>
        <p>Receive, review, and manage adoption applications professionally.</p>
      </div>
    </div>
  </section>

  <section class="image-banner">
    <div class="overlay">
      <h2>Every Child Deserves Love, Safety, and Opportunity</h2>
      <p>Technology can help care teams focus more on people and less on paperwork.</p>
    </div>
  </section>

  <section class="testimonial-section">
    <h2>Why This Project Is Valuable</h2>
    <div class="feature-box">
      <div class="card testimonial-card">
        <p>"A digital system improves record keeping and makes management faster."</p>
        <h4>Project Benefit</h4>
      </div>
      <div class="card testimonial-card">
        <p>"Donation tracking becomes more transparent and easier to manage."</p>
        <h4>System Strength</h4>
      </div>
      <div class="card testimonial-card">
        <p>"The dashboard gives a clear overview of daily orphanage operations."</p>
        <h4>Admin Advantage</h4>
      </div>
    </div>
  </section>

  <section class="highlight-section">
    <div class="highlight-box">
      <h2>Together, We Can Create Hope</h2>
      <p>
        This platform helps orphanages focus more on care and less on paperwork.
        It is built to support better planning, better reporting, and better service.
      </p>
      <a href="about.php" class="btn">Learn More</a>
    </div>
  </section>

  <footer class="main-footer">
    <div class="footer-content">
      <div class="footer-box">
        <h3>OMS</h3>
        <p>A web-based orphanage management system for better care and organization.</p>
      </div>
      <div class="footer-box">
        <h3>Quick Links</h3>
        <p><a href="index.php">Home</a></p>
        <p><a href="about.php">About</a></p>
        <p><a href="donate.php">Donate</a></p>
        <p><a href="contact.php">Contact</a></p>
      </div>
      <div class="footer-box">
        <h3>Contact</h3>
        <p><i class="fa-solid fa-envelope mr-2"></i> info@oms.com</p>
        <p><i class="fa-solid fa-phone mr-2"></i> +234 000 000 0000</p>
        <p><i class="fa-solid fa-location-dot mr-2"></i> Your City</p>
      </div>
    </div>
    <p class="footer-bottom">&copy; 2026 Orphanage Management System. All rights reserved.</p>
  </footer>
  </main>
</body>
</html>