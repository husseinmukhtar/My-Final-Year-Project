<?php
include("includes/db.php");
$sql = "ALTER TABLE donations ADD COLUMN currency VARCHAR(10) DEFAULT 'USD' AFTER amount";
if ($conn->query($sql) === TRUE) {
    echo "Table donations altered successfully";
} else {
    echo "Error altering table: " . $conn->error;
}
$conn->close();
?>
