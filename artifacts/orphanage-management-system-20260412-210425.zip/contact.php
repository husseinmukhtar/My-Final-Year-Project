<?php
include("includes/db.php");
$message_status = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $message = trim($_POST["message"]);

    if (empty($full_name) || empty($email) || empty($message)) {
        $message_status = "Please fill in all fields.";
    } else {
        $sql = "INSERT INTO contacts (full_name, email, message) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $full_name, $email, $message);

        if ($stmt->execute()) {
            $message_status = "Message sent successfully.";
        } else {
            $message_status = "Failed to send message.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact - OMS</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header>
    <nav class="navbar">
      <h1 class="logo">OMS</h1>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="donate.php">Donate</a></li>
        <li><a href="login.php">Login</a></li>
      </ul>
    </nav>
  </header>

  <section class="form-section">
    <h2>Contact Us</h2>
    <div class="form-container">
      <?php if ($message_status): ?>
        <p style="margin-bottom: 15px; color: #153677; font-weight: bold;"><?php echo $message_status; ?></p>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="full_name" placeholder="Enter your full name" />
        </div>

        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" placeholder="Enter your email" />
        </div>

        <div class="form-group">
          <label>Message</label>
          <textarea name="message" rows="5" placeholder="Write your message"></textarea>
        </div>

        <button type="submit" class="submit-btn">Send Message</button>
      </form>
    </div>
  </section>
</body>
</html>